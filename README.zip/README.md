# saloni portfolio

hey welcome to my portfolio.

it's coming up to tomorrow when I learn HTML and CSS with Tanya 
pratap live on youtube.
And I am learn:
1 javascript
2 HTML
3 CSS